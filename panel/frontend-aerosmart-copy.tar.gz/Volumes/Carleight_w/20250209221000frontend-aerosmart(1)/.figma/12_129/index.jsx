import React from 'react';

import styles from './index.module.scss';

const Component = () => {
  return (
    <img src="../image/mlgm0b4z-01wnnpg.png" className={styles.frame} />
  );
}

export default Component;
