import React from 'react';

import styles from './index.module.scss';

const Component = () => {
  return (
    <div className={styles.appWindowAppWindow}>
      <div className={styles.autoWrapper}>
        <p className={styles.a1}>1</p>
        <p className={styles.a348}>348</p>
        <p className={styles.a660}>660</p>
        <p className={styles.a708}>708</p>
        <p className={styles.a1020}>1020</p>
        <p className={styles.a1252}>1252</p>
        <p className={styles.a1930}>1930</p>
      </div>
      <div className={styles.autoWrapper2}>
        <div className={styles.ellipse} />
        <div className={styles.ellipse2} />
        <div className={styles.ellipse3} />
        <div className={styles.ellipse4} />
        <div className={styles.ellipse5} />
        <div className={styles.ellipse6} />
        <div className={styles.ellipse7} />
        <div className={styles.rectangle} />
      </div>
      <div className={styles.surfaceAppSurface}>
        <div className={styles.appBaseFill}>
          <div className={styles.appBaseShadow}>
            <div className={styles.appBaseStroke}>
              <div className={styles.frame9}>
                <div className={styles.frame7}>
                  <img
                    src="../image/mlgm92ta-ojjthgs.svg"
                    className={styles.frame4}
                  />
                </div>
                <div className={styles.frame38}>
                  <div className={styles.icons2}>
                    <img
                      src="../image/mlgm92ta-qq02gsk.svg"
                      className={styles.icons}
                    />
                  </div>
                  <div className={styles.icons3}>
                    <img
                      src="../image/mlgm92ta-z6eg227.svg"
                      className={styles.icons}
                    />
                  </div>
                  <div className={styles.icons3}>
                    <img
                      src="../image/mlgm92ta-mmimg76.svg"
                      className={styles.icons}
                    />
                  </div>
                </div>
                <div className={styles.icons4}>
                  <img
                    src="../image/mlgm92ta-3kubt3n.svg"
                    className={styles.icons}
                  />
                </div>
              </div>
              <div className={styles.frame40}>
                <div className={styles.frame41}>
                  <div className={styles.button}>
                    <p className={styles.overview}>Overview</p>
                  </div>
                  <p className={styles.sensor}>Sensor</p>
                  <p className={styles.power}>Power</p>
                </div>
                <div className={styles.frame49}>
                  <div className={styles.frame61}>
                    <div className={styles.frame67}>
                      <div className={styles.frame63}>
                        <p className={styles.text}>风速输入</p>
                        <div className={styles.frame62}>
                          <p className={styles.text2}>风速（m/s）</p>
                          <div className={styles.rectangle3} />
                        </div>
                      </div>
                      <div className={styles.frame65}>
                        <p className={styles.text3}>当前风速</p>
                        <div className={styles.frame64}>
                          <p className={styles.a0}>0</p>
                          <p className={styles.mS}>m/s</p>
                        </div>
                      </div>
                    </div>
                    <div className={styles.frame57} />
                  </div>
                  <div className={styles.frame60} />
                  <div className={styles.frame612}>
                    <div className={styles.frame59} />
                    <div className={styles.frame57} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Component;
