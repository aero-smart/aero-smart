import React from 'react';

import styles from './index.module.scss';

const Component = () => {
  return (
    <div className={styles.frame9}>
      <div className={styles.frame7}>
        <img src="../image/mlgmbprg-ovgdxzb.svg" className={styles.frame4} />
      </div>
      <div className={styles.frame38}>
        <div className={styles.icons2}>
          <img src="../image/mlgmbprg-tvr50dq.svg" className={styles.icons} />
        </div>
        <div className={styles.icons3}>
          <img src="../image/mlgmbprg-j09lczf.svg" className={styles.icons} />
        </div>
        <div className={styles.icons3}>
          <img src="../image/mlgmbprg-cvq7hok.svg" className={styles.icons} />
        </div>
      </div>
      <div className={styles.icons4}>
        <img src="../image/mlgmbprg-34j6jgv.svg" className={styles.icons} />
      </div>
    </div>
  );
}

export default Component;
