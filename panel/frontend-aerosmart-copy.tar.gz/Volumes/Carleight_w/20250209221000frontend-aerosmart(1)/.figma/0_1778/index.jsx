import React from 'react';

import styles from './index.module.scss';

const Component = () => {
  return (
    <div className={styles.surfaceAppSurface}>
      <div className={styles.appBaseFill}>
        <div className={styles.appBaseShadow}>
          <div className={styles.appBaseStroke} />
        </div>
      </div>
    </div>
  );
}

export default Component;
